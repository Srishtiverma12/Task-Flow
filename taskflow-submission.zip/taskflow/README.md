# ✦ Taskflow — Simple Task Manager

> Internship Assignment | Growify India | Full-Stack Web Development

A full-stack task management application built with **React**, **Node.js/Express**, **MongoDB**, and **JWT authentication**.

---

## 🚀 Live Demo

- **Frontend:** `https://your-frontend.vercel.app`
- **Backend API:** `https://your-backend.railway.app`

---

## ✨ Features

- **Authentication** — Register & Login with hashed passwords (bcryptjs), JWT-protected routes
- **Create Tasks** — Add tasks with title and optional description
- **View Tasks** — See all your tasks, filterable by All / Pending / Completed
- **Edit Tasks** — Update title and description via modal
- **Delete Tasks** — Remove tasks with confirmation
- **Toggle Status** — Mark tasks as Pending or Completed with one click
- **Responsive Design** — Works on mobile and desktop

---

## 🛠 Tech Stack

| Layer     | Technology                          |
|-----------|-------------------------------------|
| Frontend  | React 18, React Router v6, Axios, Vite |
| Backend   | Node.js, Express.js                 |
| Database  | MongoDB Atlas + Mongoose            |
| Auth      | JWT (jsonwebtoken) + bcryptjs       |
| Styling   | CSS Modules                         |
| Deployment| Vercel (frontend) + Railway (backend) |

---

## 📁 Project Structure

```
taskflow/
├── backend/
│   ├── middleware/
│   │   └── auth.js          # JWT protection middleware
│   ├── models/
│   │   ├── User.js          # User schema (email, hashed password)
│   │   └── Task.js          # Task schema (title, desc, status, user ref)
│   ├── routes/
│   │   ├── auth.js          # POST /register, POST /login
│   │   └── tasks.js         # GET, POST, PUT, DELETE /tasks
│   ├── .env.example
│   ├── package.json
│   └── server.js            # Express app entry point
│
└── frontend/
    ├── src/
    │   ├── api/
    │   │   └── index.js     # Axios instance + all API calls
    │   ├── components/
    │   │   ├── EditModal.jsx / .module.css
    │   │   ├── TaskCard.jsx / .module.css
    │   │   ├── TaskFilters.jsx / .module.css
    │   │   ├── TaskForm.jsx / .module.css
    │   │   ├── TaskList.jsx / .module.css
    │   │   └── Topbar.jsx / .module.css
    │   ├── context/
    │   │   └── AuthContext.jsx  # React context for auth state
    │   ├── pages/
    │   │   ├── AuthPage.jsx / .module.css
    │   │   └── Dashboard.jsx / .module.css
    │   ├── App.jsx              # Routes (public/private)
    │   ├── main.jsx
    │   └── index.css
    ├── index.html
    ├── vite.config.js
    └── package.json
```

---

## ⚙️ Local Setup

### Prerequisites
- Node.js v18+
- MongoDB Atlas account (free tier works)
- npm or yarn

---

### 1. Clone the Repository

```bash
git clone https://github.com/yourusername/taskflow.git
cd taskflow
```

---

### 2. Backend Setup

```bash
cd backend
npm install
cp .env.example .env
```

Edit `.env` with your values:

```env
PORT=5000
MONGO_URI=mongodb+srv://<user>:<pass>@cluster.mongodb.net/taskflow
JWT_SECRET=your_super_secret_key
CLIENT_URL=http://localhost:5173
```

Start the backend:

```bash
# Development (with auto-reload)
npm run dev

# Production
npm start
```

Backend runs at: `http://localhost:5000`

---

### 3. Frontend Setup

```bash
cd ../frontend
npm install
cp .env.example .env
```

Edit `.env`:

```env
VITE_API_URL=http://localhost:5000/api
```

Start the frontend:

```bash
npm run dev
```

Frontend runs at: `http://localhost:5173`

---

## 📡 API Reference

### Auth Endpoints

| Method | Endpoint            | Body                        | Description        |
|--------|---------------------|-----------------------------|--------------------|
| POST   | `/api/auth/register` | `{ email, password }`      | Register new user  |
| POST   | `/api/auth/login`    | `{ email, password }`      | Login, returns JWT |

### Task Endpoints *(All require `Authorization: Bearer <token>`)*

| Method | Endpoint          | Body                            | Description       |
|--------|-------------------|---------------------------------|-------------------|
| GET    | `/api/tasks`      | —                               | Get all user tasks |
| POST   | `/api/tasks`      | `{ title, description? }`       | Create a task     |
| PUT    | `/api/tasks/:id`  | `{ title?, description?, status? }` | Update a task |
| DELETE | `/api/tasks/:id`  | —                               | Delete a task     |

---

## 🗄 Database Schema

### User
```js
{
  email:     String (unique, required),
  password:  String (hashed with bcryptjs),
  createdAt: Date,
  updatedAt: Date
}
```

### Task
```js
{
  user:        ObjectId (ref: User),   // One-to-Many relationship
  title:       String (required),
  description: String (optional),
  status:      "Pending" | "Completed",
  createdAt:   Date,
  updatedAt:   Date
}
```

---

## 🚢 Deployment Guide

### Backend → Railway

1. Push code to GitHub
2. Go to [railway.app](https://railway.app) → New Project → Deploy from GitHub
3. Select `backend/` as root directory
4. Add environment variables (same as `.env`)
5. Railway auto-detects Node.js and deploys

### Frontend → Vercel

1. Go to [vercel.com](https://vercel.com) → New Project → Import GitHub repo
2. Set **Root Directory** to `frontend`
3. Add environment variable: `VITE_API_URL=https://your-backend.railway.app/api`
4. Deploy

---

## 🎯 Evaluation Checklist

- [x] **Backend (40%)** — CRUD, JWT auth, error handling, proper status codes
- [x] **Frontend (30%)** — Clean UI, form validation, API integration, loading/error states
- [x] **Database (15%)** — Mongoose schemas, User → Tasks one-to-many relationship
- [x] **Code Quality (10%)** — Component structure, CSS modules, clean naming
- [x] **Deployment (5%)** — Vercel + Railway ready

---

## 👤 Author

**Your Name**  
Web Development Intern  
Growify India Assignment
