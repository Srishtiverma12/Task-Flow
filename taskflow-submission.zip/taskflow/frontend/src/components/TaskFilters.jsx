import styles from "./TaskFilters.module.css";

export default function TaskFilters({ filter, setFilter, counts }) {
  const filters = [
    { label: "All", count: counts.all },
    { label: "Pending", count: counts.pending },
    { label: "Completed", count: counts.done },
  ];

  return (
    <div className={styles.filters}>
      {filters.map(({ label, count }) => (
        <button
          key={label}
          className={`${styles.btn} ${filter === label ? styles.active : ""}`}
          onClick={() => setFilter(label)}
        >
          {label} <span className={styles.count}>{count}</span>
        </button>
      ))}
    </div>
  );
}
