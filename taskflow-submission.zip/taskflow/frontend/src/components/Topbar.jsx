import { useNavigate } from "react-router-dom";
import { useAuth } from "../context/AuthContext";
import styles from "./Topbar.module.css";

const LogoutIcon = () => (
  <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"/>
    <polyline points="16 17 21 12 16 7"/>
    <line x1="21" y1="12" x2="9" y2="12"/>
  </svg>
);

export default function Topbar({ user }) {
  const { logout } = useAuth();
  const navigate = useNavigate();

  const handleLogout = () => {
    logout();
    navigate("/login");
  };

  return (
    <header className={styles.topbar}>
      <div className={styles.logo}>✦ Taskflow</div>
      <div className={styles.right}>
        <div className={styles.userPill}>
          <div className={styles.avatar}>{user?.email?.[0]?.toUpperCase()}</div>
          <span className={styles.email}>{user?.email}</span>
        </div>
        <button className={styles.logoutBtn} onClick={handleLogout}>
          <LogoutIcon />
          <span>Logout</span>
        </button>
      </div>
    </header>
  );
}
