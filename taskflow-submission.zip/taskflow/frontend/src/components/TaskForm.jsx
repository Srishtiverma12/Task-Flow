import { useState } from "react";
import styles from "./TaskForm.module.css";

export default function TaskForm({ onCreate }) {
  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!title.trim()) { setError("Title is required"); return; }
    setError(""); setLoading(true);
    try {
      await onCreate({ title: title.trim(), description: description.trim() });
      setTitle(""); setDescription("");
    } catch (err) {
      setError(err.response?.data?.error || "Failed to create task");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className={styles.form}>
      <div className={styles.formTitle}>+ New Task</div>
      <form onSubmit={handleSubmit} noValidate>
        <div className={styles.row}>
          <div className={styles.field}>
            <label>Title <span>*</span></label>
            <input
              value={title}
              onChange={e => { setTitle(e.target.value); setError(""); }}
              placeholder="What needs to be done?"
            />
            {error && <span className={styles.err}>{error}</span>}
          </div>
          <div className={styles.field}>
            <label>Description</label>
            <input
              value={description}
              onChange={e => setDescription(e.target.value)}
              placeholder="Optional details..."
            />
          </div>
        </div>
        <div className={styles.actions}>
          <button type="submit" className={styles.addBtn} disabled={loading}>
            {loading ? "Adding..." : "Add Task"}
          </button>
        </div>
      </form>
    </div>
  );
}
