import TaskCard from "./TaskCard";
import styles from "./TaskList.module.css";

export default function TaskList({ tasks, filter, onToggle, onEdit, onDelete }) {
  if (tasks.length === 0) {
    return (
      <div className={styles.empty}>
        <div className={styles.emptyIcon}>{filter === "Completed" ? "✅" : "📋"}</div>
        <p>{filter === "All" ? "No tasks yet. Add one above!" : `No ${filter.toLowerCase()} tasks.`}</p>
      </div>
    );
  }

  return (
    <div className={styles.list}>
      {tasks.map((task) => (
        <TaskCard
          key={task._id}
          task={task}
          onToggle={onToggle}
          onEdit={onEdit}
          onDelete={onDelete}
        />
      ))}
    </div>
  );
}
