import { useState } from "react";
import styles from "./TaskCard.module.css";

const EditIcon = () => (
  <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"/>
    <path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"/>
  </svg>
);

const TrashIcon = () => (
  <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <polyline points="3 6 5 6 21 6"/>
    <path d="M19 6l-1 14H6L5 6"/>
    <path d="M10 11v6"/><path d="M14 11v6"/>
    <path d="M9 6V4h6v2"/>
  </svg>
);

export default function TaskCard({ task, onToggle, onEdit, onDelete }) {
  const [deleting, setDeleting] = useState(false);
  const done = task.status === "Completed";

  const date = new Date(task.createdAt).toLocaleDateString("en-US", {
    month: "short", day: "numeric", year: "numeric",
  });

  const handleDelete = async () => {
    if (!window.confirm("Delete this task?")) return;
    setDeleting(true);
    try { await onDelete(task._id); }
    catch { setDeleting(false); }
  };

  return (
    <div className={`${styles.card} ${done ? styles.done : ""}`}>
      <button
        className={`${styles.check} ${done ? styles.checked : ""}`}
        onClick={() => onToggle(task)}
        aria-label="Toggle task status"
      />
      <div className={styles.body}>
        <div className={styles.title}>{task.title}</div>
        {task.description && <div className={styles.desc}>{task.description}</div>}
        <div className={styles.meta}>
          <span className={`${styles.badge} ${done ? styles.badgeDone : styles.badgePending}`}>
            {task.status}
          </span>
          <span className={styles.date}>{date}</span>
        </div>
      </div>
      <div className={styles.actions}>
        <button className={styles.iconBtn} onClick={() => onEdit(task)} aria-label="Edit task">
          <EditIcon />
        </button>
        <button className={`${styles.iconBtn} ${styles.deleteBtn}`} onClick={handleDelete} disabled={deleting} aria-label="Delete task">
          <TrashIcon />
        </button>
      </div>
    </div>
  );
}
