import { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { useAuth } from "../context/AuthContext";
import styles from "./AuthPage.module.css";

export default function AuthPage({ mode }) {
  const isLogin = mode === "login";
  const { login, register } = useAuth();
  const navigate = useNavigate();

  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [errors, setErrors] = useState({});
  const [globalErr, setGlobalErr] = useState("");
  const [loading, setLoading] = useState(false);

  const validate = () => {
    const e = {};
    if (!email.trim()) e.email = "Email is required";
    else if (!/\S+@\S+\.\S+/.test(email)) e.email = "Invalid email format";
    if (!password) e.password = "Password is required";
    else if (password.length < 6) e.password = "Minimum 6 characters";
    return e;
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    const errs = validate();
    if (Object.keys(errs).length) { setErrors(errs); return; }
    setErrors({}); setGlobalErr(""); setLoading(true);
    try {
      if (isLogin) await login(email, password);
      else await register(email, password);
      navigate("/");
    } catch (err) {
      setGlobalErr(err.response?.data?.error || "Something went wrong. Try again.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className={styles.wrap}>
      <div className={styles.box}>
        <div className={styles.logo}>✦ Taskflow</div>
        <p className={styles.subtitle}>Manage your tasks with clarity</p>

        <div className={styles.tabs}>
          <Link to="/login" className={`${styles.tab} ${isLogin ? styles.active : ""}`}>Sign In</Link>
          <Link to="/register" className={`${styles.tab} ${!isLogin ? styles.active : ""}`}>Register</Link>
        </div>

        {globalErr && <div className={styles.globalErr}>{globalErr}</div>}

        <form onSubmit={handleSubmit} noValidate>
          <div className={styles.field}>
            <label>Email</label>
            <input type="email" value={email} onChange={e => setEmail(e.target.value)} placeholder="you@example.com" autoFocus />
            {errors.email && <span className={styles.err}>{errors.email}</span>}
          </div>
          <div className={styles.field}>
            <label>Password</label>
            <input type="password" value={password} onChange={e => setPassword(e.target.value)} placeholder="••••••••" />
            {errors.password && <span className={styles.err}>{errors.password}</span>}
          </div>
          <button type="submit" className={styles.btnPrimary} disabled={loading}>
            {loading
              ? (isLogin ? "Signing in..." : "Creating account...")
              : (isLogin ? "Sign In" : "Create Account")}
          </button>
        </form>

        <p className={styles.switchText}>
          {isLogin ? "No account? " : "Already have an account? "}
          <Link to={isLogin ? "/register" : "/login"} className={styles.switchLink}>
            {isLogin ? "Register →" : "Sign in →"}
          </Link>
        </p>
      </div>
    </div>
  );
}
