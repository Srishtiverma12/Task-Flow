import { useState, useEffect, useCallback } from "react";
import { useAuth } from "../context/AuthContext";
import { getTasks, createTask, updateTask, deleteTask } from "../api";
import Topbar from "../components/Topbar";
import TaskForm from "../components/TaskForm";
import TaskFilters from "../components/TaskFilters";
import TaskList from "../components/TaskList";
import EditModal from "../components/EditModal";
import styles from "./Dashboard.module.css";

export default function Dashboard() {
  const { user } = useAuth();
  const [tasks, setTasks] = useState([]);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState("All");
  const [editTask, setEditTask] = useState(null);
  const [error, setError] = useState("");

  const fetchTasks = useCallback(async () => {
    try {
      const { data } = await getTasks();
      setTasks(data);
    } catch {
      setError("Failed to load tasks. Please refresh.");
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => { fetchTasks(); }, [fetchTasks]);

  const handleCreate = async ({ title, description }) => {
    const { data } = await createTask({ title, description });
    setTasks((prev) => [data, ...prev]);
  };

  const handleToggle = async (task) => {
    const newStatus = task.status === "Completed" ? "Pending" : "Completed";
    const { data } = await updateTask(task._id, { status: newStatus });
    setTasks((prev) => prev.map((t) => (t._id === data._id ? data : t)));
  };

  const handleEdit = async (updates) => {
    const { data } = await updateTask(editTask._id, updates);
    setTasks((prev) => prev.map((t) => (t._id === data._id ? data : t)));
    setEditTask(null);
  };

  const handleDelete = async (id) => {
    await deleteTask(id);
    setTasks((prev) => prev.filter((t) => t._id !== id));
  };

  const filtered = tasks.filter((t) =>
    filter === "All" ? true : t.status === filter
  );

  const pending = tasks.filter((t) => t.status === "Pending").length;
  const done = tasks.filter((t) => t.status === "Completed").length;

  return (
    <div className={styles.app}>
      <Topbar user={user} />
      <main className={styles.main}>
        <div className={styles.pageHeader}>
          <h1 className={styles.pageTitle}>Your <span>Tasks</span></h1>
          <div className={styles.statsRow}>
            <span className={styles.statChip}><span className={`${styles.dot} ${styles.dotAll}`} />{tasks.length} Total</span>
            <span className={styles.statChip}><span className={`${styles.dot} ${styles.dotPending}`} />{pending} Pending</span>
            <span className={styles.statChip}><span className={`${styles.dot} ${styles.dotDone}`} />{done} Completed</span>
          </div>
        </div>

        {error && <div className={styles.errorBanner}>{error}</div>}

        <TaskForm onCreate={handleCreate} />
        <TaskFilters filter={filter} setFilter={setFilter} counts={{ all: tasks.length, pending, done }} />

        {loading
          ? <div className={styles.loadingWrap}><div className={styles.spinner} /></div>
          : <TaskList tasks={filtered} filter={filter} onToggle={handleToggle} onEdit={setEditTask} onDelete={handleDelete} />}
      </main>

      {editTask && <EditModal task={editTask} onSave={handleEdit} onClose={() => setEditTask(null)} />}
    </div>
  );
}
