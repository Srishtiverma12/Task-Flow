const express = require("express");
const cors = require("cors");
const mongoose = require("mongoose");
require("dotenv").config();

const authRoutes = require("./routes/auth");
const taskRoutes = require("./routes/tasks");
const { protect } = require("./middleware/auth");

const app = express();

// ── Middleware ──
app.use(cors({ origin: process.env.CLIENT_URL || "*", credentials: true }));
app.use(express.json());

// ── Routes ──
app.get("/", (req, res) => res.json({ message: "Taskflow API is running ✦" }));
app.use("/api/auth", authRoutes);
app.use("/api/tasks", protect, taskRoutes);

// ── 404 handler ──
app.use((req, res) => res.status(404).json({ error: "Route not found" }));

// ── Global error handler ──
app.use((err, req, res, next) => {
  console.error(err.stack);
  res.status(err.status || 500).json({ error: err.message || "Internal server error" });
});

// ── Connect DB & start server ──
const PORT = process.env.PORT || 5000;

mongoose
  .connect(process.env.MONGO_URI)
  .then(() => {
    console.log("✦ MongoDB connected");
    app.listen(PORT, () => console.log(`✦ Server running on port ${PORT}`));
  })
  .catch((err) => {
    console.error("MongoDB connection error:", err.message);
    process.exit(1);
  });
