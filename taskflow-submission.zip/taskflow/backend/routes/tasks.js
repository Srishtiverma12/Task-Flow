const express = require("express");
const Task = require("../models/Task");

const router = express.Router();

// GET /api/tasks — get all tasks for logged-in user
router.get("/", async (req, res) => {
  try {
    const tasks = await Task.find({ user: req.user._id }).sort({ createdAt: -1 });
    res.json(tasks);
  } catch (err) {
    res.status(500).json({ error: "Failed to fetch tasks" });
  }
});

// POST /api/tasks — create a new task
router.post("/", async (req, res) => {
  try {
    const { title, description } = req.body;

    if (!title || !title.trim())
      return res.status(400).json({ error: "Title is required" });

    const task = await Task.create({
      user: req.user._id,
      title: title.trim(),
      description: description?.trim() || "",
    });

    res.status(201).json(task);
  } catch (err) {
    if (err.name === "ValidationError") {
      const messages = Object.values(err.errors).map((e) => e.message);
      return res.status(400).json({ error: messages.join(", ") });
    }
    res.status(500).json({ error: "Failed to create task" });
  }
});

// PUT /api/tasks/:id — update a task
router.put("/:id", async (req, res) => {
  try {
    const { title, description, status } = req.body;

    const task = await Task.findOne({ _id: req.params.id, user: req.user._id });
    if (!task) return res.status(404).json({ error: "Task not found" });

    if (title !== undefined) task.title = title.trim();
    if (description !== undefined) task.description = description.trim();
    if (status !== undefined) {
      if (!["Pending", "Completed"].includes(status))
        return res.status(400).json({ error: "Status must be Pending or Completed" });
      task.status = status;
    }

    await task.save();
    res.json(task);
  } catch (err) {
    if (err.name === "CastError") return res.status(400).json({ error: "Invalid task ID" });
    res.status(500).json({ error: "Failed to update task" });
  }
});

// DELETE /api/tasks/:id — delete a task
router.delete("/:id", async (req, res) => {
  try {
    const task = await Task.findOneAndDelete({ _id: req.params.id, user: req.user._id });
    if (!task) return res.status(404).json({ error: "Task not found" });
    res.json({ message: "Task deleted successfully" });
  } catch (err) {
    if (err.name === "CastError") return res.status(400).json({ error: "Invalid task ID" });
    res.status(500).json({ error: "Failed to delete task" });
  }
});

module.exports = router;
